class Cat {
  constructor({ name, pattern, size, description }) {
    this.name = name;
    this.pattern = pattern;
    this.size = size;
    this.description = description;
  }
}

module.exports = Cat;